#version 120

#define DAWN_SHADER

#define OVERWORLD_SHADER

#include "/dimensions/composite4.vsh"