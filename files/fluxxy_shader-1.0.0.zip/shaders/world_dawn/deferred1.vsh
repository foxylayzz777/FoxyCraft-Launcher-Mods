#version 120

#define DAWN_SHADER

#define OVERWORLD_SHADER

#include "/dimensions/deferred1.vsh"